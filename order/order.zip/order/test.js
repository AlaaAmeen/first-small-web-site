function sayThank() {
   
    alert("Thank you for buying from our site :) ");
}